<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * OKMindmap authentication
 *
 * @package    auth_okmmauth
 * @copyright  Nguyen Van Hoang <nvhoangag@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../../config.php');
require_once($CFG->dirroot . '/course/lib.php');
require_once($CFG->dirroot . '/course/edit_form.php');
require_once(__DIR__ . '/auth.php');

class okmindmap_services
{
    protected $auth;

    public function __construct()
    {
        $this->auth =  new auth_plugin_okmmauth();
    }

    public function require_login($request)
    {
        $user = $this->auth->account_sync($request->auth, $request->username, $request->firstname, $request->lastname, $request->email, $request->role);
        complete_user_login($user);
        return $user;
    }

    public function create_course($request)
    {
        global $CFG, $DB;
        $user = $this->require_login($request);
        $data = new stdClass();
        $data->fullname = html_entity_decode($request->fullname);
        $data->shortname = html_entity_decode($request->shortname);
        $data->category = $request->category;
        $data->summary = html_entity_decode($request->summary);
        $course = create_course($data);

        $context = context_course::instance($course->id, MUST_EXIST);
        if (!empty($CFG->creatornewroleid) and !is_viewing($context, NULL, 'moodle/role:assign') and !is_enrolled($context, NULL, 'moodle/role:assign')) {
            enrol_try_internal_enrol($course->id, $user->id, $CFG->creatornewroleid);
        }

        // $this->auth->setCourseConfig($course->id, 'okmmMapId', $request->okmmMapId);

        return ['status' => 'ok', 'message' => '', 'course' => $course->id];
    }

    public function set_course_connection($request)
    {
        global $CFG, $DB;
        $user = $this->require_login($request);
        $this->auth->setCourseConfig($request->moodleCourseId, 'okmmMapId', $request->okmmMapId);
    }

    public function delete_course_connection($request)
    {
        global $CFG, $DB;
        $user = $this->require_login($request);
        $query = 'DELETE FROM {config_plugins} WHERE plugin = ? AND name LIKE ?';
        $res = $DB->get_records_sql($query, array('auth_okmmauth', 'course.' . $request->moodleCourseId . '.%'));
        \cache_helper::invalidate_by_definition('core', 'config', array(), 'auth_okmmauth');
    }

    public function edit_course($request)
    {
        global $CFG, $DB;
        $user = $this->require_login($request);

        $value = $this->auth->getCourseConfig($request->moodleCourseId, 'okmmMapId');

        if ($value == $request->okmmMapId) {
            $obj = new stdClass();
            $obj->id = intval($request->moodleCourseId);
            $obj->fullname = html_entity_decode($request->name);
            // $obj->shortname = $request->name;
            $res = $DB->update_record('course', $obj);
            rebuild_course_cache($obj->id);
            if ($res) return ['status' => 'ok', 'message' => ''];
        }
        return ['status' => 'error', 'message' => ''];
    }

    public function edit_section($request)
    {
        global $CFG, $DB;
        $user = $this->require_login($request);

        $value = $this->auth->getCourseConfig($request->moodleCourseId, 'okmmMapId');

        if ($value == $request->okmmMapId) {
            $id = $DB->get_field('course_sections', 'id', array('course' => $request->moodleCourseId, 'section' => $request->section));
            $obj = new stdClass();
            $obj->id = $id;
            $obj->name = html_entity_decode($request->name);
            $res = $DB->update_record('course_sections', $obj);
            rebuild_course_cache($request->moodleCourseId);
            if ($res) return ['status' => 'ok', 'message' => ''];
        }
        return ['status' => 'error', 'message' => ''];
    }

    public function move_to_section($request)
    {
        global $CFG, $DB;
        $user = $this->require_login($request);

        $value = $this->auth->getCourseConfig($request->moodleCourseId, 'okmmMapId');

        if ($value == $request->okmmMapId) {
            $cm = get_coursemodule_from_id(null, $request->module, $request->moodleCourseId, false, MUST_EXIST);
            $section = $DB->get_record('course_sections', array('course' => $cm->course, 'section' => $request->section));
            $res = moveto_module($cm, $section, null);
            rebuild_course_cache($request->moodleCourseId);
            if ($res) return ['status' => 'ok', 'message' => ''];
        }
        return ['status' => 'error', 'message' => ''];
    }

    public function edit_module($request)
    {
        global $CFG, $DB;
        $user = $this->require_login($request);

        $value = $this->auth->getCourseConfig($request->moodleCourseId, 'okmmMapId');
        $module = get_coursemodule_from_id('', intval($request->moodleModuleId), 0, false, MUST_EXIST);

        if ($module != null && $value == $request->okmmMapId) {
            $obj = new stdClass();
            $obj->id = $module->instance;
            $obj->name = html_entity_decode($request->name);
            $obj->intro = html_entity_decode($request->intro);
            $obj->timemodified = time();
            $res = $DB->update_record($request->moodleModule, $obj);
            rebuild_course_cache($module->course);

            $this->auth->setModuleConfig($module->course, $module->id, 'okmmNodeId', $request->okmmNodeId);

            if ($res) return ['status' => 'ok', 'message' => ''];
        }
        return ['status' => 'error', 'message' => ''];
    }

    public function get_activities($request)
    {
        global $CFG, $DB, $PAGE, $OUTPUT;
        $user = $this->require_login($request);

        $course = $DB->get_record('course', array('id' => $request->moodleCourseId));
        $PAGE->set_context(context_system::instance());
        $modules = get_module_metadata($course, get_module_types_names());
        $res = new stdClass();
        $res->activities = [];
        // $res->resources = [];
        $res->course_menus = [];
        $lang = isset($request->lang) ? $request->lang : 'en';
        $trans = get_string_manager();
        if (has_capability('moodle/course:update', context_course::instance($course->id), $user)) {
            array_push($res->course_menus, [
                'title' => $trans->get_string('course_administration.edit_settings', 'auth_okmmauth', null, $lang),
                'name' => 'fn',
                'link' => urlencode((new moodle_url($CFG->wwwroot . '/auth/okmmauth/services.php', ['redirect' => urlencode($CFG->wwwroot . '/course/edit.php?id=' . $course->id)]))->out()),
                'icon' => html_writer::empty_tag('img', array('src' => $OUTPUT->pix_url('i/settings', 'core')->out(true)))
            ]);
        }
        if (has_capability('enrol/manual:enrol', context_course::instance($course->id), $user)) {
            array_push($res->course_menus, [
                'title' => $trans->get_string('course_administration.enrolled_users', 'auth_okmmauth', null, $lang),
                'name' => 'fn',
                'link' => urlencode((new moodle_url($CFG->wwwroot . '/auth/okmmauth/services.php', ['redirect' => urlencode($CFG->wwwroot . '/enrol/users.php?id=' . $course->id)]))->out()),
                'icon' => html_writer::empty_tag('img', array('src' => $OUTPUT->pix_url('i/enrolusers', 'core')->out(true)))
            ]);
        }
        if (has_capability('report/log:view', context_course::instance($course->id), $user)) {
            array_push($res->course_menus, [
                'title' => $trans->get_string('course_administration.log_view', 'auth_okmmauth', null, $lang),
                'name' => 'fn',
                'link' => urlencode((new moodle_url($CFG->wwwroot . '/auth/okmmauth/services.php', ['redirect' => urlencode($CFG->wwwroot . '/report/log/index.php?id=' . $course->id)]))->out()),
                'icon' => html_writer::empty_tag('img', array('src' => $OUTPUT->pix_url('i/report', 'core')->out(true)))
            ]);
        }
        if (has_capability('report/progress:view', context_course::instance($course->id), $user)) {
            array_push($res->course_menus, [
                'title' => $trans->get_string('course_administration.activity_completion', 'auth_okmmauth', null, $lang),
                'name' => 'fn',
                'link' => urlencode((new moodle_url($CFG->wwwroot . '/auth/okmmauth/services.php', ['redirect' => urlencode($CFG->wwwroot . '/report/progress/index.php?course=' . $course->id)]))->out()),
                'icon' => html_writer::empty_tag('img', array('src' => $OUTPUT->pix_url('i/report', 'core')->out(true)))
            ]);
        }
        if (has_capability('gradereport/grader:view', context_course::instance($course->id), $user)) {
            array_push($res->course_menus, [
                'title' => $trans->get_string('course_administration.grades', 'auth_okmmauth', null, $lang),
                'name' => 'fn',
                'link' => urlencode((new moodle_url($CFG->wwwroot . '/auth/okmmauth/services.php', ['redirect' => urlencode($CFG->wwwroot . '/grade/report/index.php?id=' . $course->id)]))->out()),
                'icon' => html_writer::empty_tag('img', array('src' => $OUTPUT->pix_url('i/grades', 'core')->out(true)))
            ]);
        }
        if (has_capability('moodle/badges:awardbadge', context_course::instance($course->id), $user)) {
            array_push($res->course_menus, [
                'title' => $trans->get_string('course_administration.badges', 'auth_okmmauth', null, $lang),
                'name' => 'fn',
                'link' => urlencode((new moodle_url($CFG->wwwroot . '/auth/okmmauth/services.php', ['redirect' => urlencode($CFG->wwwroot . '/badges/index.php?type=2&id=' . $course->id)]))->out()),
                'icon' => html_writer::empty_tag('img', array('src' => $OUTPUT->pix_url('i/navigationitem', 'core')->out(true)))
            ]);
        }

        $conf = $this->auth->config;
        $obj = new stdClass();
        $obj->auth = $request->auth;
        $obj->role = $request->role;
        $obj->username = $request->username;
        $obj->firstname = $request->firstname;
        $obj->lastname = $request->lastname;
        $obj->email = $request->email;
        $obj->info = 'create_activity.do';
        $obj->moodleCourseId = $course->id;
        // $aq = $this->auth->encrypt(json_encode($obj), $conf->secret);
        $filter = [
            'assign', 'chat', 'forum', 'wiki',
            'resource', 'quiz', 'page', 'url'
        ];
        foreach ($modules as $module) {
            // $link = $module->link->params();
            $q = $obj;
            $q->module = $module->name;
            $params = [
                'title' => $trans->get_string('activities.' . $module->name, 'auth_okmmauth', null, $lang),
                'icon' => $module->icon,
                // 'course'=>$link['id'], 
                // 'sesskey'=>$link['sesskey'], 
                'name' => $module->name,
                // 'link'=> (new moodle_url($CFG->wwwroot.'/auth/okmmauth/modedit.php', ['add'=>$link['add'], 'course'=>$link['id'], 'section'=>'', 'aq'=>$aq ]))->out()
                'link' => (new moodle_url($CFG->wwwroot . '/auth/okmmauth/services.php', ['q' => $this->auth->encrypt(json_encode($q), $conf->secret)]))->out()
            ];
            // if($module->archetype == MOD_CLASS_ACTIVITY){
            //     array_push($res->activities, $params);
            // }else{
            //     array_push($res->resources, $params);
            // }
            if (in_array($params['name'], $filter)) {
                array_push($res->activities, $params);
            }
        }
        return ['status' => 'ok', 'message' => '', 'activities' => $res];
    }

    public function create_activity($request)
    {
        global $CFG, $DB, $PAGE, $OUTPUT;
        $user = $this->require_login($request);

        $course = $DB->get_record('course', array('id' => $request->moodleCourseId));
        $PAGE->set_context(context_system::instance());
        $modules = get_module_metadata($course, [$request->module => $request->module]);

        $link = $modules[$request->module]->link->params();
        redirect((new moodle_url($CFG->wwwroot . '/auth/okmmauth/modedit.php', ['add' => $link['add'], 'course' => $course->id, 'section' => isset($_REQUEST['section']) ? $_REQUEST['section'] : '', 'mapid' => $_REQUEST['mapid'], 'mapkey' => $_REQUEST['mapkey']]))->out());
    }

    public function add_module($request)
    {
        global $CFG, $DB, $PAGE;
        $user = $this->require_login($request);
        $PAGE->set_context(context_system::instance());
        $course = $DB->get_record('course', array('id' => intval($request->moodleCourseId)));
        $moduleId = $DB->get_field('modules', 'id', array(
            'name' => $request->moduleName
        ));

        $data = new stdClass();

        $data->section          = intval($request->section);
        $data->visible          = 1;
        $data->course           = $course->id;
        $data->module           = $moduleId;
        $data->modulename       = $request->moduleName;
        $data->name             = $request->name;
        $data->intro            = $request->moduleName == 'label' ? $request->name : '';
        $data->introformat      = 0;
        $data->instance         = '';
        $data->coursemodule     = '';
        $data->add              = '';

        $modmoodleform = "$CFG->dirroot/mod/$request->moduleName/mod_form.php";
        if (file_exists($modmoodleform)) {
            require_once($modmoodleform);
        } else {
            return ['status' => 'error', 'message' => 'noformdesc'];
        }
        $mformclassname = 'mod_' . $request->moduleName . '_mod_form';
        $mform = new $mformclassname($data, null, null, $course);

        $reflect = new ReflectionClass($mform);
        $p = $reflect->getProperty('_form');
        $p->setAccessible(true);
        $mformData = $p->getValue($mform);
        $parseField = function ($field) {
            preg_match('/(?<filed>\w+)\[(?<key>\w+)\]/', $field, $matchs, PREG_OFFSET_CAPTURE);
            return $matchs;
        };
        foreach ($mformData->_elementIndex as $field => $idx) {
            $element = $mformData->_elements[$idx];
            $pureField = strrpos($field, '[') === false;
            $matchs = [];
            if (!$pureField) {
                $matchs = $parseField($field);
                $field = $matchs['filed'][0];
                if (!isset($data->$field)) $data->$field = [];
                $data->{$field}[$matchs['key'][0]] = '';
            } else if (!isset($data->$field) && $field != 'introeditor') {
                if (isset($element->_attributes) && isset($element->_attributes['value'])) {
                    $data->$field = $element->_attributes['value'];
                } else {
                    $data->$field =  '';
                }
            }
        }
        foreach ($mformData->_defaultValues as $field => $value) {
            if (strrpos($field, '[') === false) {
                $data->$field = $value;
            } else {
                $matchs = $parseField($field);
                $field = $matchs['filed'][0];
                $data->{$field}[$matchs['key'][0]] = $value;
            }
        }

        try {
            $res = add_moduleinfo($data, $course);
            rebuild_course_cache($course->id);
            $link = $res->modulename == 'label' ? '' : $CFG->wwwroot . "/mod/" . $res->modulename . "/view.php?id=" . $res->coursemodule;
            $res->link = $link;
            return ['status' => 'ok', 'message' => '', 'module' => $res];
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => ''];
        }
    }

    public function delete_module($request)
    {
        global $CFG, $DB, $PAGE;
        $user = $this->require_login($request);

        $course = $DB->get_record('course', array('id' => intval($request->moodleCourseId)));
        $value = $this->auth->getModuleConfig($request->moodleCourseId, $request->moodleModuleId, 'okmmNodeId');
        if ($value != $request->okmmNodeId) return ['status' => 'error', 'message' => ''];
        try {
            $cm = get_coursemodule_from_id(null, intval($request->moodleModuleId), $course->id, false, MUST_EXIST);
            // course_delete_module($cm->id);
            $this->auth->deleteModuleConfig($request->moodleCourseId, $request->moodleModuleId, 'okmmNodeId');
            rebuild_course_cache($course->id);
            return ['status' => 'ok', 'message' => ''];
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => ''];
        }
    }

    public function get_modules($request)
    {
        global $CFG, $DB;
        $user = $this->require_login($request);

        $value = $this->auth->getCourseConfig($request->moodleCourseId, 'okmmMapId');
        if ($value != $request->okmmMapId) return ['status' => 'error', 'message' => ''];
        try {
            $course = $DB->get_record('course', array('id' => intval($request->moodleCourseId)));
            $sections = $DB->get_records_sql('SELECT section,name,sequence FROM {course_sections} WHERE course = ? AND sequence <> \'\' AND visible = 1 ORDER BY section ASC', array($course->id));
            $modules = $DB->get_records('course_modules', ['course' => $course->id, 'visible' => 1]);
            $c = new stdClass();
            $c->fullname = $course->fullname;

            $res = ['course' => $c, 'sections' => new stdClass(), 'modules' => new stdClass(), 'sequence' => new stdClass(), 'section_order' => ''];
            $section_order = '';
            foreach ($sections as $section) {
                // if($section->section != 0){
                $res['sections']->{'section_' . $section->section} = $section->name == '' ? ($section->section != 0 ? 'Topic ' . $section->section : 'General') : $section->name;

                if ($section_order != '') $section_order .= ',';
                $section_order .= $section->section;
                // } 
                $res['sequence']->{'section_' . $section->section} = $section->sequence;
            }
            $res['section_order'] = $section_order;

            foreach ($modules as $module) {
                $cm = get_coursemodule_from_id(null, $module->id, $course->id, false, MUST_EXIST);
                $m = new stdClass();
                $m->id = $cm->id;
                $m->name = $cm->name;
                $m->modname = $cm->modname;
                $m->section = $DB->get_field('course_sections', 'section', array('id' => $cm->section));
                $m->link = $cm->modname == 'label' ? '' : urlencode((new moodle_url($CFG->wwwroot . '/auth/okmmauth/services.php', ['redirect' => urlencode($CFG->wwwroot . "/mod/" . $cm->modname . "/view.php?id=" . $cm->id)]))->out());
                $res['modules']->{'mod_' . $cm->id} = $m;
            }

            return ['status' => 'ok', 'data' => $res];
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => ''];
        }
    }

    public function dev_get_modules($request)
    {
        global $CFG, $DB;
        // $user = $this->require_login($request);

        $value = $this->auth->getCourseConfig($request->moodleCourseId, 'okmmMapId');
        if ($value != $request->okmmMapId) return ['status' => 'error', 'message' => ''];
        try {
            $course = $DB->get_record('course', array('id' => intval($request->moodleCourseId)));
            $sections = $DB->get_records_sql('SELECT section,name,sequence FROM {course_sections} WHERE course = ? AND sequence <> \'\' AND visible = 1 ORDER BY section ASC', array($course->id));
            $modules = $DB->get_records('course_modules', ['course' => $course->id, 'visible' => 1]);
            $c = new stdClass();
            $c->fullname = $course->fullname;

            $res = ['course' => $c, 'sections' => new stdClass(), 'modules' => new stdClass(), 'sequence' => new stdClass(), 'section_order' => ''];
            $section_order = '';
            foreach ($sections as $section) {
                // if($section->section != 0){
                $res['sections']->{'section_' . $section->section} = $section->name == '' ? ($section->section != 0 ? 'Topic ' . $section->section : 'General') : $section->name;

                if ($section_order != '') $section_order .= ',';
                $section_order .= $section->section;
                // } 
                $res['sequence']->{'section_' . $section->section} = $section->sequence;
            }
            $res['section_order'] = $section_order;

            foreach ($modules as $module) {
                $cm = get_coursemodule_from_id(null, $module->id, $course->id, false, MUST_EXIST);
                $m = new stdClass();
                $m->id = $cm->id;
                $m->name = $cm->name;
                $m->modname = $cm->modname;
                $m->section = $DB->get_field('course_sections', 'section', array('id' => $cm->section));
                $m->link = $cm->modname == 'label' ? '' : urlencode((new moodle_url($CFG->wwwroot . '/auth/okmmauth/services.php', ['redirect' => urlencode($CFG->wwwroot . "/mod/" . $cm->modname . "/view.php?id=" . $cm->id)]))->out());
                $res['modules']->{'mod_' . $cm->id} = $m;
            }

            return ['status' => 'ok', 'data' => $res];
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => ''];
        }
    }

    public function course_enrolment($request)
    {
        global $CFG, $DB, $PAGE;
        require_once($CFG->dirroot . '/enrol/locallib.php');

        $this->require_login($request);

        $listview = isset($request->listview) ? $request->listview : true;
        $course = $DB->get_record('course', array('id' => intval($request->moodleCourseId)), '*', MUST_EXIST);
        $context = context_course::instance($course->id, MUST_EXIST);
        $manager = new course_enrolment_manager($PAGE, $course);
        $enrolid = $DB->get_field('enrol', 'id', array('enrol' => 'manual', 'courseid' => $course->id));

        $as_teacher_roles = ['editingteacher']; // 'teacher', 'coursecreator', 'manager'

        if (isset($request->action)) {
            switch ($request->action) {
                case 'enrol':
                    $_id = 0;
                    if (isset($request->enroluser) && isset($request->enroluser->okmmauth)) {
                        $enroluser = $this->auth->account_sync('okmmauth', $request->enroluser->username, $request->enroluser->firstname, $request->enroluser->lastname, $request->enroluser->email);
                        $_id = $enroluser->id;
                    } else {
                        $_id = intval($request->enroluser->id);
                    }
                    $roleid = $DB->get_field('role', 'id', array('shortname' => 'student'));
                    if (!is_enrolled($context, $_id) && !enrol_try_internal_enrol($course->id, $_id, $roleid, time())) {
                        // throw new moodle_exception('unabletoenrolerrormessage', 'langsourcefile');
                    }

                    if (isset($request->enroluser->assign_role)) {
                        $roleid = $DB->get_field('role', 'id', array('shortname' => $request->enroluser->assign_role));
                        if (is_enrolled($context, $_id)) {
                            role_assign($roleid, $_id, $context->id);
                        }
                    }

                    if (!$listview) return;
                    break;
                case 'unenrol':
                    $_id = 0;
                    if (isset($request->enroluser) && isset($request->enroluser->okmmauth)) {
                        $_id = $DB->get_field('user', 'id', array('auth' => 'okmmauth', 'username' => $request->enroluser->username));
                    } else {
                        $_id = intval($request->enroluser->id);
                    }

                    $ue = $DB->get_record('user_enrolments', array('enrolid' => $enrolid, 'userid' => $_id), '*', MUST_EXIST);
                    list($instance, $plugin) = $manager->get_user_enrolment_components($ue);
                    if (!$instance || !$plugin || !enrol_is_enabled($instance->enrol) || !$plugin->allow_unenrol_user($instance, $ue) || !$manager->unenrol_user($ue)) {
                        // throw new enrol_ajax_exception('unenrolnotpermitted');
                    }
                    if (!$listview) return;
                    break;
                case 'assign_teacher':
                    $user = null;
                    if (isset($request->enroluser) && isset($request->enroluser->okmmauth)) {
                        $user = $DB->get_record('user', array('auth' => 'okmmauth', 'username' => $request->enroluser->username), '*', MUST_EXIST);
                    } else {
                        $user = $DB->get_record('user', array('id' => intval($request->enroluser->id)), '*', MUST_EXIST);
                    }

                    $roleid = $DB->get_field('role', 'id', array('shortname' => 'editingteacher'));
                    if (is_enrolled($context, $user)) {
                        role_assign($roleid, $user->id, $context->id);
                    }
                    if (!$listview) return;
                    break;
                case 'unassign_teacher':
                    $user = null;
                    if (isset($request->enroluser) && isset($request->enroluser->okmmauth)) {
                        $user = $DB->get_record('user', array('auth' => 'okmmauth', 'username' => $request->enroluser->username), '*', MUST_EXIST);
                    } else {
                        $user = $DB->get_record('user', array('id' => intval($request->enroluser->id)), '*', MUST_EXIST);
                    }

                    $roleid = $DB->get_field('role', 'id', array('shortname' => 'editingteacher'));
                    if (is_enrolled($context, $user)) {
                        role_unassign($roleid, $user->id, $context->id);
                    }
                    if (!$listview) return;
                    break;
                case 'check_okmmusers':
                    $okmmauth = [];

                    if (isset($request->okmmusers) && is_array($request->okmmusers)) {
                        foreach ($request->okmmusers as $username) {
                            $userid = $DB->get_field('user', 'id', array('auth' => 'okmmauth', 'username' => $username));
                            $okmmauth[$username] = is_enrolled($context, $userid) ? 1 : 0;

                            $can_teacher = 0;
                            foreach (get_user_roles($context, $userid) as $role) {
                                if (in_array($role->shortname, $as_teacher_roles)) {
                                    $can_teacher = 1;
                                    break;
                                }
                            }
                            $okmmauth[$username . '_is_teacher'] = $can_teacher;
                        }
                    }
                    return $okmmauth;
            }
        }

        $search = isset($request->search) ? $request->search : '';
        $page = isset($request->page) ? $request->page : 0;
        $perpage = isset($request->perpage) ? $request->perpage : 25;
        $data = $manager->get_potential_users(null, $search, null, $page, $perpage);

        $rows = [];
        $totalusers = $data['totalusers'];
        foreach ($data['users'] as $user) {
            $auth = $DB->get_field('user', 'auth', array('id' => $user->id));

            if ($auth == 'okmmauth') {
                $totalusers--;
            } else {
                $user->is_enrolled = is_enrolled($context, $user->id) ? 1 : 0;

                $can_teacher = 0;
                foreach (get_user_roles($context, $user->id) as $role) {
                    if (in_array($role->shortname, $as_teacher_roles)) {
                        $can_teacher = 1;
                        break;
                    }
                }
                $user->is_teacher = $can_teacher;

                array_push($rows, $user);
            }
        }

        return ['course' => $course->id, 'users' => $rows, 'totalusers' => $totalusers, 'total_enrolled_users' => count_enrolled_users($context)];
    }

    public function enrolled_users($request)
    {
        global $CFG, $DB, $PAGE;
        require_once($CFG->dirroot . '/enrol/locallib.php');

        $course = $DB->get_record('course', array('id' => intval($request->moodleCourseId)), '*', MUST_EXIST);
        $context = context_course::instance($course->id, MUST_EXIST);
        $manager = new course_enrolment_manager($PAGE, $course);
        $enrolid = $DB->get_field('enrol', 'id', array('enrol' => 'manual', 'courseid' => $course->id));

        $users = [];
        $as_teacher_roles = ['editingteacher']; // 'teacher', 'coursecreator', 'manager'
        foreach (get_enrolled_users($context) as $user) {
            $u = new stdClass();
            $u->id = $user->id;
            $u->auth = $user->auth;

            if ($user->auth == 'okmmauth') {
                $u->auth = 'okmmauth';
                $u->username = $user->username;
            } else {
                $u->auth = 'moodle';
                $u->username = $this->auth->getIdEncrypt($user);
            }

            $u->firstname = $user->firstname;
            $u->lastname = $user->lastname;
            $u->email = $user->email;

            $can_teacher = 0;
            foreach (get_user_roles($context, $user->id) as $role) {
                if (in_array($role->shortname, $as_teacher_roles)) {
                    $can_teacher = 1;
                    break;
                }
            }
            $u->is_teacher = $can_teacher;

            array_push($users, $u);
        }

        return $users;
    }

    public function course_categories($request)
    {
        global $CFG, $DB, $PAGE;
        // $user = $this->require_login($request);

        $categories = $DB->get_records('course_categories', null, 'path', 'id, name, depth');
        $res = [];
        foreach ($categories as $category) {
            array_push($res, $category);
            // $catcontext = context_coursecat::instance($category->id);
            // if(has_capability('moodle/course:create', $catcontext, $user)){
            //     array_push($res, $category);
            // }
        }
        return ['categories' => $res];
    }

    public function get_courses($request)
    {
        global $CFG, $DB, $PAGE;
        require_once($CFG->dirroot . '/enrol/locallib.php');
        $user = $this->require_login($request);

        $search = '';
        $params = null;

        if (!empty($request->search) && !empty($request->searchfield)) {
            $search = 'WHERE ' . $request->searchfield . ' LIKE ?';
            $params = array('%' . $request->search . '%');
        }

        $query = 'SELECT * FROM {course} ' . $search . ' ORDER BY timemodified DESC';
        $res = $DB->get_records_sql($query, $params, max(0, $request->page - 1) * $request->pagelimit, $request->pagelimit);
        $courses = [];

        foreach ($res as $course) {
            $context = context_course::instance($course->id, MUST_EXIST);
            $manager = new course_enrolment_manager($PAGE, $course);

            $as_teacher_roles = ['editingteacher']; // 'teacher', 'coursecreator', 'manager'
            $can_teacher = 0;
            foreach (get_user_roles($context, $user->id) as $role) {
                if (in_array($role->shortname, $as_teacher_roles)) {
                    $can_teacher = 1;
                    break;
                }
            }
            $c = new stdClass();
            $c->id = $course->id;
            $c->fullname = $course->fullname;
            $c->is_teacher = $can_teacher;
            $okmmMapId = $this->auth->getCourseConfig($course->id, 'okmmMapId');
            $c->okmmMapId = $okmmMapId == '' ? '0' : $okmmMapId;
            array_push($courses, $c);
        }

        return ['courses' => $courses];
    }

    public function get_moodleCourseId($request)
    {
        global $CFG, $DB, $PAGE;
        $user = $this->require_login($request);

        $select = sprintf("plugin = :plugin AND %s = :value", $DB->sql_compare_text('value'));
        $result = $DB->get_record_select('config_plugins', $select, array('plugin' => 'auth_okmmauth', 'value' => $request->okmmMapId));

        return [
            'moodleCourseId' => $result? explode('.', $result->name)[1] : "",
        ];
    }

    public function dev_get_moodleCourseId($request)
    {
        global $CFG, $DB, $PAGE;
        // $user = $this->require_login($request);

        $select = sprintf("plugin = :plugin AND %s = :value", $DB->sql_compare_text('value'));
        $result = $DB->get_record_select('config_plugins', $select, array('plugin' => 'auth_okmmauth', 'value' => $request->okmmMapId));

        return [
            'moodleCourseId' => $result? explode('.', $result->name)[1] : "",
        ];
    }
}
