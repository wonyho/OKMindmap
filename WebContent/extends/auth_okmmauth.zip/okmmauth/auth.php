<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * OKMindmap authentication.
 *
 * @package   auth_okmmauth
 * @copyright Nguyen Van Hoang <nvhoangag@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir.'/authlib.php');

class auth_plugin_okmmauth extends auth_plugin_base {

    protected $plugin_name =  'auth_okmmauth';

    public $defaults = array(
        'url'            => '',
        'secret'          => '',    // 16 characters
        'idpname'         => '',
        'showidplink'     => true,
        'debug'           => false,
    );

    /**
     * Constructor.
     */
    public function __construct() {
        $this->authtype = 'okmmauth';
        $this->config = (object) array_merge($this->defaults, (array) get_config($this->plugin_name) );
    }

    /**
     * A debug function, dumps to the php log
     *
     * @param string $msg Log message
     */
    private function log($msg) {
        if ($this->config->debug) {
            // @codingStandardsIgnoreStart
            error_log('auth_okmmauth: ' . $msg);
            // @codingStandardsIgnoreEnd
        }
    }

    /**
     * Returns a list of potential IdPs that this authentication plugin supports.
     * This is used to provide links on the login page.
     *
     * @param string $wantsurl the relative url fragment the user wants to get to.
     *
     * @return array of IdP's
     */
    public function loginpage_idp_list($wantsurl) {
        // If we have disabled the visibility of the idp link, return with an empty array right away.
        if (!$this->config->showidplink) {
            return array();
        }

        // The wants url may already be routed via login.php so don't re-re-route it.
        if (strpos($wantsurl, '/auth/okmmauth/login.php')) {
            $wantsurl = new moodle_url($wantsurl);
        } else {
            $wantsurl = new moodle_url('/auth/okmmauth/login.php', array('wants' => $wantsurl));
        }

        $conf = $this->config;
        return array(
            array(
                'url'  => $wantsurl,
                'icon' => new pix_icon('i/user', 'Login'),
                'name' => (!empty($conf->idpname) ? $conf->idpname : 'OKMindmap'),
            ),
        );
    }

    /**
     * All the checking happens before the login page in this hook
     */
    public function pre_loginpage_hook() {

        $this->log(__FUNCTION__ . ' enter');
        $this->loginpage_hook();
        $this->log(__FUNCTION__ . ' exit');
    }

    /**
     * All the checking happens before the login page in this hook
     */
    public function loginpage_hook() {
        global $CFG, $DB, $USER, $SESSION;
        //
    }

    public function okmm_login(){
        if(isloggedin()) redirect(new moodle_url('/'));
        else {
            $conf = $this->config;
            $mdlurl = (string) new moodle_url('/');
            $auth = new stdClass();
            $auth->url = $mdlurl;
            $auth = $this->encrypt(json_encode($auth), $conf->secret);
            redirect($this->str_finish($conf->url, '/').'user/login.do?auth='.$auth.'&mdlurl='.$mdlurl);
        }
    }

    public function callback_handler($auth){
        global $CFG, $DB, $SESSION;
        $conf = $this->config;
        $userAuth = json_decode($this->decrypt($auth, $conf->secret));
        if($userAuth != '' && isset($userAuth->auth) && isset($userAuth->role) && isset($userAuth->username)){
            $user = $this->account_sync($userAuth->auth, $userAuth->username, $userAuth->firstname, $userAuth->lastname, $userAuth->email, $userAuth->role);
            complete_user_login($user);
            redirect(new moodle_url('/'));
        }
        redirect(new moodle_url('/login/index.php'));
    }

    public function account_sync($auth, $username, $firstname = '', $lastname = '', $email = '', $role = ''){
        global $CFG, $DB, $SESSION;
        
        $user = null;

        if($auth == 'moodle'){
            $user = $DB->get_record('user', array('id'=>$this->getIdDecrypt($username)));
        }else{
            $user = $DB->get_record('user', array('username'=>$username, 'auth'=>'okmmauth'));
            
            if($user == null){
                require_once($CFG->dirroot . '/user/lib.php');
                
                $user = new stdClass();
                $user->mnethostid = $CFG->mnet_localhost_id;
                $user->confirmed = 1;
                $user->username = $username;
                $user->password = AUTH_PASSWORD_NOT_CACHED;
                $user->firstname = isset($firstname) ? html_entity_decode($firstname) : '';
                $user->lastname = isset($lastname) ? html_entity_decode($lastname) : '';
                $user->email = isset($email) ? $email : '';
                $user->auth = 'okmmauth';
                
                $id = user_create_user($user, false);
                
                $user = $DB->get_record('user', array('id'=>$id));
            }else {
                $obj = new stdClass();
                $obj->id = $user->id;
                if(isset($firstname) && $firstname != '') $obj->firstname = html_entity_decode($firstname);
                if(isset($lastname) && $lastname != '') $obj->lastname = html_entity_decode($lastname);
                if(isset($email)) $obj->email = $email;
                $DB->update_record('user', $obj);
                $user = $DB->get_record('user', array('username'=>$username, 'auth'=>'okmmauth'));
            }
        }

        if($role != '' && $user != null) {
            if($roleAssign = $DB->get_record('role', array('shortname'=>$role))) {
                $context = context_system::instance();
                role_assign($roleAssign->id, $user->id, $context->id);
            }
        }
        return $user;
    }

    /**
     * Returns false regardless of the username and password as we never get
     * to the web form. If we do, some other auth plugin will handle it
     *
     * @param string $username The username
     * @param string $password The password
     * @return bool Authentication success or failure.
     *
     * @SuppressWarnings("unused")
     */
    public function user_login ($username, $password) {
        return false;
    }

    /**
     * Prints a form for configuring this authentication plugin.
     *
     * This function is called from admin/auth.php, and outputs a full page with
     * a form for configuring this plugin.
     *
     * @param object $config
     * @param object $err
     * @param array $userfields
     *
     * @SuppressWarnings("unused")
     */
    public function config_form($config, $err, $userfields) {
        $config = (object) array_merge($this->defaults, (array) $config );
        include("config.php");
    }

    /**
     * Processes and stores configuration data for this authentication plugin.
     *
     * @param object $config
     */
    public function process_config($config) {
		$con = get_config($this->plugin_name);
        foreach ($this->defaults as $key => $value) {
            set_config($key, $config->$key, $this->plugin_name);
        }
		
		set_config('version', $con->version, $this->plugin_name);
        return true;
    }

    public function setCourseConfig($course, $name, $value){
        set_config(join('.', ['course', $course, $name]), $value, $this->plugin_name);
    }
    public function getCourseConfig($course, $name){
        \cache_helper::invalidate_by_definition('core', 'config', array(), $this->plugin_name);
        return get_config($this->plugin_name, join('.', ['course', $course, $name]));
    }
    public function deleteCourseConfig($course, $name){
        global $DB;
        $DB->delete_records('config_plugins', [
            'plugin' => $this->plugin_name,
            'name' => join('.', ['course', $course, $name])
        ]);
    }

    public function setModuleConfig($course, $module, $name, $value){
        set_config(join('.', ['course', $course, 'module', $module, $name]), $value, $this->plugin_name);
    }
    public function getModuleConfig($course, $module, $name){
        \cache_helper::invalidate_by_definition('core', 'config', array(), $this->plugin_name);
        return get_config($this->plugin_name, join('.', ['course', $course, 'module', $module, $name]));
    }
    public function deleteModuleConfig($course, $module, $name){
        global $DB;
        $DB->delete_records('config_plugins', [
            'plugin' => $this->plugin_name,
            'name' => join('.', ['course', $course, 'module', $module, $name])
        ]);
    }

    /**
     * AES Encrypt
     */
    public function encrypt($input, $key) {
        $size = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_ECB); 
        $pad = $size - (strlen($input) % $size);
		$input = $input . str_repeat(chr($pad), $pad); 
		$td = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_ECB, ''); 
		$iv = mcrypt_create_iv(mcrypt_enc_get_iv_size($td), MCRYPT_RAND); 
		mcrypt_generic_init($td, $key, $iv); 
		$data = mcrypt_generic($td, $input);
		mcrypt_generic_deinit($td); 
		mcrypt_module_close($td); 
        $data = base64_encode($data); 
        $data = strtr($data, '+/=', '-_,');
		return $data; 
    }
    
    /**
     * AES Decrypt
     */
    public function decrypt($sStr, $sKey) {
        $sStr = strtr($sStr, '-_,', '+/=');
		$decrypted= mcrypt_decrypt(
			MCRYPT_RIJNDAEL_128,
			$sKey, 
			base64_decode($sStr), 
			MCRYPT_MODE_ECB
		);
		$dec_s = strlen($decrypted); 
		$padding = ord($decrypted[$dec_s-1]); 
		$decrypted = substr($decrypted, 0, -$padding);
		return $decrypted;
    }
    
    public function getIdEncrypt($user){
        return $user->id . '_' . md5($user->username);
    }

    public function getIdDecrypt($stringId){
        return intval(explode('_', $stringId, 2)[0]);
    }

    public function str_finish($string, $delimiter){
        return substr($string, -1, 1) == $delimiter ? $string : $string.$delimiter;
    }

}

