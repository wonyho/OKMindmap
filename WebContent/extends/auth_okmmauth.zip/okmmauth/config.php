<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * OKMindmap authentication.
 *
 * @package   auth_okmmauth
 * @copyright Nguyen Van Hoang <nvhoangag@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$yesno = array(get_string('no'), get_string('yes'));

?>

<table cellspacing="0" cellpadding="5" border="0">
    <tr valign="top">
        <?php $field = 'url' ?>
        <td align="right"><label for="<?php echo $field ?>"><?php print_string($field, 'auth_okmmauth') ?></label></td>
        <td><input type="text" size="40" name="<?php echo $field ?>" value="<?php print $config->$field ?>" placeholder="//okmindmap.com"><br>
            <?php if (isset($err[$field])) { echo $OUTPUT->notification($err[$field], 'notifyfailure'); } ?>
        </td>
    </tr>

    <tr valign="top">
        <?php $field = 'secret' ?>
        <td align="right"><label for="<?php echo $field ?>"><?php print_string($field, 'auth_okmmauth') ?></label></td>
        <td><input type="text" size="40" name="<?php echo $field ?>" value="<?php print $config->$field ?>" placeholder="<?php print_string($field, 'auth_okmmauth') ?>"><br>
            <?php if (isset($err[$field])) { echo $OUTPUT->notification($err[$field], 'notifyfailure'); } ?>
        </td>
    </tr>

    <tr valign="top">
        <?php $field = 'idpname' ?>
        <td align="right"><label for="<?php echo $field ?>"><?php print_string($field, 'auth_okmmauth') ?></label></td>
        <td><input type="text" size="40" name="<?php echo $field ?>" value="<?php print $config->$field ?>" placeholder="OKMindmap"><br>
            <?php if (isset($err[$field])) { echo $OUTPUT->notification($err[$field], 'notifyfailure'); } ?>
        </td>
    </tr>

    <tr valign="top">
        <?php $field = 'showidplink' ?>
        <td align="right"><label for="<?php echo $field ?>"><?php print_string($field, 'auth_okmmauth') ?></label></td>
        <td><?php echo html_writer::select($yesno, $field, $config->$field, false) ?>
            <?php if (isset($err[$field])) { echo $OUTPUT->notification($err[$field], 'notifyfailure'); } ?>
        </td>
    </tr>

    <tr valign="top">
        <?php $field = 'debug' ?>
        <td align="right"><label for="<?php echo $field ?>"><?php print_string($field, 'auth_okmmauth') ?></label></td>
        <td><?php echo html_writer::select($yesno, $field, $config->$field, false) ?>
            <?php if (isset($err[$field])) { echo $OUTPUT->notification($err[$field], 'notifyfailure'); } ?>
        </td>
    </tr>
</table>