<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * OKMindmap authentication
 *
 * @package    auth_okmmauth
 * @copyright  Nguyen Van Hoang <nvhoangag@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once(__DIR__.'/../../config.php');
require_once(__DIR__.'/../../course/lib.php');
require_once(__DIR__.'/../../course/modlib.php');
require_once(__DIR__.'/auth.php');

$services = array(
    'create_course.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'create_course',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'edit_course.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'edit_course',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'get_activities.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'get_activities',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'add_module.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'add_module',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'edit_module.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'edit_module',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'delete_module.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'delete_module',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'get_modules.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'get_modules',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'course_enrolment.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'course_enrolment',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'course_categories.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'course_categories',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'enrolled_users.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'enrolled_users',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'edit_section.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'edit_section',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'move_to_section.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'move_to_section',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'set_course_connection.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'set_course_connection',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'delete_course_connection.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'delete_course_connection',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'create_activity.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'create_activity',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'get_courses.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'get_courses',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
    'get_moodleCourseId.do' => array(
        'classname' => 'okmindmap_services',
        'methodname' => 'get_moodleCourseId',
        'classpath' => 'okmindmap_services.php',
        'enabled' => true,
    ),
);

if(!function_exists('mcrypt_encrypt')) {
    die('Mcrypt is not installed.');
}

$res = ['status'=>'error', 'message'=>'Whoops, looks like something went wrong'];

if(isset($_REQUEST['redirect'])) {
    if(isset($_REQUEST['auth']) && isset($_REQUEST['username']) && isset($_REQUEST['firstname']) && isset($_REQUEST['lastname']) && isset($_REQUEST['email'])) {
        $auth = new auth_plugin_okmmauth();
        $user = $auth->account_sync($_REQUEST['auth'], $_REQUEST['username'], urldecode($_REQUEST['firstname']), urldecode($_REQUEST['lastname']), urldecode($_REQUEST['email']), 'student');
        complete_user_login($user);
    }
    redirect(new moodle_url(urldecode($_REQUEST['redirect'])));
}

if(isset($_REQUEST['q'])){
    $auth = new auth_plugin_okmmauth();
    $conf = $auth->config;
    $userAuth = json_decode($auth->decrypt($_REQUEST['q'], $conf->secret));
    if($userAuth != '' && isset($userAuth->auth) && isset($userAuth->role) && isset($userAuth->username) && isset($userAuth->info) && isset($services[$userAuth->info])){
        $fn = $services[$userAuth->info];
        if ($fn['enabled'] === true) {
            require_once(__DIR__ . '/' . $fn['classpath']);
            try{
                $res = (new $fn['classname']())->{$fn['methodname']}($userAuth);
            }catch (\Exception $e) {
                $res = ['status'=>'error', 'message'=>$e->getMessage()];
            }
        }
    }
}

if(isset($_REQUEST['dev'])){
    $auth = new auth_plugin_okmmauth();
    // require_once(__DIR__ . '/okmindmap_services.php');
    try{
        switch ($_REQUEST['dev']) {
            case 'getCourseConfig':
                $res = $auth->getCourseConfig($_REQUEST['moodleCourseId'], $_REQUEST['name']);
                break;
            case 'setCourseConfig':
                $res = $auth->setCourseConfig($_REQUEST['moodleCourseId'], 'okmmMapId', $_REQUEST['okmmMapId']);
                break;
            case 'deleteCourseConfig':
                global $DB;
                $query = 'DELETE FROM {config_plugins} WHERE plugin = ? AND name LIKE ?';
                $res = $DB->get_records_sql($query, array('auth_okmmauth', 'course.'.$_REQUEST['moodleCourseId'].'.%'));
                \cache_helper::invalidate_by_definition('core', 'config', array(), 'auth_okmmauth');
                break;
            case 'dev_get_modules':
                require_once(__DIR__ . '/okmindmap_services.php');
                try{
                    $req = new stdClass();
                    $req->moodleCourseId = $_REQUEST['moodleCourseId'];
                    $req->okmmMapId = $_REQUEST['okmmMapId'];

                    $res = (new okmindmap_services())->dev_get_modules($req);
                }catch (\Exception $e) {
                    $res = ['status'=>'error', 'message'=>$e->getMessage()];
                }
                break;
            case 'dev_get_moodleCourseId':
                require_once(__DIR__ . '/okmindmap_services.php');
                try{
                    $req = new stdClass();
                    $req->okmmMapId = $_REQUEST['okmmMapId'];

                    $res = (new okmindmap_services())->dev_get_moodleCourseId($req);
                }catch (\Exception $e) {
                    $res = ['status'=>'error', 'message'=>$e->getMessage()];
                }
                break;
        }
    }catch (\Exception $e) {
        $res = ['status'=>'error', 'message'=>$e->getMessage()];
    }
}

if(isset($res['response'])) {
    require_once($res['response']);
}else echo json_encode($res);
