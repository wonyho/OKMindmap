<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * OKMindmap authentication
 *
 * @package   auth_okmmauth
 * @copyright Nguyen Van Hoang <nvhoangag@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['auth_okmmauthdescription'] = 'Users can sign in via OKMindmap account';
$string['pluginname'] = 'OKMindmap authentication';

$string['url'] = 'OKMindmap URL';
$string['secret'] = 'Secret key (16 characters)';
$string['showidplink'] = 'Display IdP link';
$string['idpname'] = 'IdP label override';
$string['debug'] = 'Debug';

$string['activities.assign'] = 'Assignment';
$string['activities.chat'] = 'Chat';
$string['activities.folder'] = 'Folder';
$string['activities.quiz'] = 'Quiz';
$string['activities.forum'] = 'Forum';
$string['activities.page'] = 'Page';
$string['activities.resource'] = 'File';
$string['activities.url'] = 'URL';
$string['activities.wiki'] = 'Wiki';

$string['course_administration.edit_settings'] = 'Edit course settings';
$string['course_administration.enrolled_users'] = 'Enrolled users';
$string['course_administration.log_view'] = 'Log view';
$string['course_administration.activity_completion'] = 'Activity completion';
$string['course_administration.grades'] = 'Grader report';
$string['course_administration.badges'] = 'Manage badges';