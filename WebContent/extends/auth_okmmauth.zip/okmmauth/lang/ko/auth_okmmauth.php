<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * OKMindmap authentication
 *
 * @package   auth_okmmauth
 * @copyright Nguyen Van Hoang <nvhoangag@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['auth_okmmauthdescription'] = '사용자는 OKMindmap 계정을 통해 로그인 할 수 있습니다.';
$string['pluginname'] = 'OKMindmap 인증';

$string['url'] = 'OKMindmap URL';
$string['secret'] = '비밀 키 (16 자)';
$string['showidplink'] = '디스플레이 IdP 링크';
$string['idpname'] = 'IdP 레이블 재정의';
$string['debug'] = '디버그';

$string['activities.assign'] = '과제';
$string['activities.chat'] = '대화방';
$string['activities.folder'] = '폴더';
$string['activities.quiz'] = '퀴즈';
$string['activities.forum'] = '포럼';
$string['activities.page'] = '웹페이지';
$string['activities.resource'] = '파일';
$string['activities.url'] = 'URL';
$string['activities.wiki'] = '위키';

$string['course_administration.edit_settings'] = '설정 수정';
$string['course_administration.enrolled_users'] = '등록된 사용자';
$string['course_administration.log_view'] = '로그보기';
$string['course_administration.activity_completion'] = '활동 완료';
$string['course_administration.grades'] = '채점자 보고서';
$string['course_administration.badges'] = '뱃지 관리';