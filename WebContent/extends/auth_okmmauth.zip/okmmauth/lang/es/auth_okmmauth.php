<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * OKMindmap authentication
 *
 * @package   auth_okmmauth
 * @copyright Nguyen Van Hoang <nvhoangag@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['auth_okmmauthdescription'] = 'Los usuarios pueden iniciar sesión a través de la cuenta OKMindmap';
$string['pluginname'] = 'Autenticación OKMindmap';

$string['url'] = 'OKMindmap URL';
$string['secret'] = 'Clave secreta (16 caracteres)';
$string['showidplink'] = 'Mostrar enlace IdP';
$string['idpname'] = 'Anulación de etiqueta de IdP';
$string['debug'] = 'Depurar';

$string['activities.assign'] = 'Tarea';
$string['activities.chat'] = 'Chat';
$string['activities.folder'] = 'Carpeta';
$string['activities.quiz'] = 'Cuestionario';
$string['activities.forum'] = 'Foro';
$string['activities.page'] = 'Página';
$string['activities.resource'] = 'Archivo';
$string['activities.url'] = 'URL';
$string['activities.wiki'] = 'Wiki';

$string['course_administration.edit_settings'] = 'Editar la configuración del curso';
$string['course_administration.enrolled_users'] = 'Usuarios matriculados';
$string['course_administration.log_view'] = 'Vista de registro';
$string['course_administration.activity_completion'] = 'Finalización de la actividad';
$string['course_administration.grades'] = 'Informe del calificador';
$string['course_administration.badges'] = 'Gestionar insignias';