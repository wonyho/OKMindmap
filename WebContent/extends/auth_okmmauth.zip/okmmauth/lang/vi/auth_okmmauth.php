<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * OKMindmap authentication
 *
 * @package   auth_okmmauth
 * @copyright Nguyen Van Hoang <nvhoangag@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['auth_okmmauthdescription'] = 'Người dùng có thể đăng nhập thông qua tài khoản OKMindmap.';
$string['pluginname'] = 'Xác thực OKMindmap';

$string['url'] = 'OKMindmap URL';
$string['secret'] = 'Khoá bí mật (16 ký tự)';
$string['showidplink'] = 'Hiển thị liên kết IdP';
$string['idpname'] = 'Ghi đè nhãn IdP';
$string['debug'] = 'Gỡ rối';

$string['activities.assign'] = 'Assignment';
$string['activities.chat'] = 'Phòng họp trực tuyến';
$string['activities.folder'] = 'Folder';
$string['activities.quiz'] = 'Đề thi';
$string['activities.forum'] = 'Diễn đàn';
$string['activities.page'] = 'Page';
$string['activities.resource'] = 'File';
$string['activities.url'] = 'URL';
$string['activities.wiki'] = 'Wiki';

$string['course_administration.edit_settings'] = 'Chỉnh sửa cài đặt';
$string['course_administration.enrolled_users'] = 'Người dùng đã ghi danh';
$string['course_administration.log_view'] = 'Xem nhật ký';
$string['course_administration.activity_completion'] = 'Hoàn thành hoạt động';
$string['course_administration.grades'] = 'Báo cáo học sinh lớp';
$string['course_administration.badges'] = 'Quản lí các huy hiệu';