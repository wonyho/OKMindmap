#include <EEPROM.h>

String flowJson = "[{\"id\":\"@@MAC_ADDR@@.@@PAYLOAD@@.e9db0c\",\"type\":\"rpi-emitter\",\"z\":\"\",\"name\":\"DHT sensor\",\"channel\":\"dhtsensor.@@MAC_ADDR@@\",\"note\":\"\",\"x\":330,\"y\":360,\"wires\":[[\"@@MAC_ADDR@@.@@PAYLOAD@@.3a43ea\"]]},{\"id\":\"@@MAC_ADDR@@.@@PAYLOAD@@.5d074\",\"type\":\"rpi-listener\",\"z\":\"\",\"name\":\"Motor control 1\",\"channel\":\"motorctrl.@@MAC_ADDR@@\",\"note\":\"\",\"x\":660,\"y\":580,\"wires\":[]},{\"id\":\"@@MAC_ADDR@@.@@PAYLOAD@@.3a43ea\",\"type\":\"okmm-dht-emitter\",\"z\":\"\",\"name\":\"DHT sensor\",\"channel\":\"dhtsensor.@@MAC_ADDR@@\",\"server\":\"@@MAC_ADDR@@.@@PAYLOAD@@.04b7\",\"note\":\"\",\"x\":640,\"y\":360,\"wires\":[]},{\"id\":\"@@MAC_ADDR@@.@@PAYLOAD@@.69a0ca\",\"type\":\"okmm-switch-listener\",\"z\":\"\",\"name\":\"Motor control 1\",\"channel\":\"motorctrl.@@MAC_ADDR@@\",\"server\":\"@@MAC_ADDR@@.@@PAYLOAD@@.04b7\",\"note\":\"\",\"x\":340,\"y\":580,\"wires\":[[\"@@MAC_ADDR@@.@@PAYLOAD@@.5d074\"]]},{\"id\":\"@@MAC_ADDR@@.@@PAYLOAD@@.ca0e9\",\"type\":\"rpi-listener\",\"z\":\"\",\"name\":\"Motor control 2\",\"channel\":\"motorctrl2.@@MAC_ADDR@@\",\"note\":\"\",\"x\":660,\"y\":640,\"wires\":[]},{\"id\":\"@@MAC_ADDR@@.@@PAYLOAD@@.5ec654\",\"type\":\"okmm-switch-listener\",\"z\":\"\",\"name\":\"Motor control 2\",\"channel\":\"motorctrl2.@@MAC_ADDR@@\",\"server\":\"@@MAC_ADDR@@.@@PAYLOAD@@.04b7\",\"note\":\"\",\"x\":340,\"y\":640,\"wires\":[[\"@@MAC_ADDR@@.@@PAYLOAD@@.ca0e9\"]]},{\"id\":\"@@MAC_ADDR@@.@@PAYLOAD@@.04b7\",\"type\":\"okmm-connector\",\"z\":\"\",\"name\":\"@@DEVICE_NAME@@\",\"channel\":\"@@MAC_ADDR@@\",\"host\":\"@@NODEJS_ADDR@@\",\"port\":\"@@NODEJS_PORT@@\"}]";


String get_flow_template(String mac, String payload, String devideName, String nodeJsAddr, String nodeJsPort){
  flowJson.replace("@@MAC_ADDR@@",mac);
  flowJson.replace("@@PAYLOAD@@",payload);
  flowJson.replace("@@DEVICE_NAME@@",devideName);
  flowJson.replace("@@NODEJS_ADDR@@",nodeJsAddr);
  flowJson.replace("@@NODEJS_PORT@@", nodeJsPort);
  return flowJson;
}

void write_String(char add,String data)
{
  int _size = data.length();
  int i;
  for(i=0;i<_size;i++)
  {
    EEPROM.write(add+i,data[i]);
  }
  EEPROM.write(add+_size,'\0');   //Add termination null character for String Data
  EEPROM.commit();
}


String read_String(char add)
{
  int i;
  char data[100]; //Max 100 Bytes
  int len=0;
  unsigned char k;
  k=EEPROM.read(add);
  while(k != '\0' && len<500)   //Read until null character
  {    
    k=EEPROM.read(add+len);
    data[len]=k;
    len++;
  }
  data[len]='\0';
  return String(data);
}
