#include "helper.h"

SocketIOClient client;
  
String switch01 = "";
String sensor01 = "";

// Node-RED server IP and port
char host[] = "133.186.143.148";
int port = 1880;

void initDevice()
{
  switch01 = "motorctrl." + macAddr;
  sensor01 = "dhtsensor." + macAddr;
}

// Call this function in setup() function
// to init Node-RED service.

void initNodeRed()
{
  EEPROM.begin(512);
  setMacAddr(WiFi.macAddress());

  // Tubestory account info
  setUserName("YOUR_USERNAME");
  setPassword("YOUR_PASSWORD");
  
  // Node-RED info
  //flowId = "FLOW_ID";
  
  // Set name for this device
  setDevicesName("YOUR_DEVICE_NAME");
  
  // NodeJs serives Info, please keep default for Tubestory
  setNodeJsAddr("http://133.186.135.53");
  setNodeJsPort("80");
  

  //Do Node-Red connection, please don't change all line bellow
  if (!client.connect(host, port, ""))
  {
    Serial.println("connection failed");
    return;
  }
  if (client.connected())
  {
    setSocketIO(client);
  }
  initDevice();
}

// This function must be defined later, where use to do action
// getNumberResponseValue(data) => return number value of event content;
// getStringResponseValue(data) => return string value of event content;

void nodeRedListenner(String event, String data);

//Example:
//void nodeRedListenner(String event, String data){
// Check event from Node-RED server;
// the name of event same with name of devices is defined in NodeRed.h
//  if(event == switch01){
//    String action = getNumberResponseValue(data);
//    demoSwicthButtonAction(action);
//    Serial.println("Do event with switch 01 ");
//  }

// Upload value to Node-RED server (json);
// demoTempSenserAction();
//}

// Call this funtion in loop() function
// to check, update, and do all Node-RED event;

void checkNodeRedConnection()
{
  if (client.connected())
  {
    //Serial.println("Socket.io connected");
    setSocketIO(client);
  }
  else
  {
    //Serial.println("Socket.io disconnected");
    client.connect(host, port, "");
  }

  if (client.monitor())
  {
    Serial.println("Socket.io event");
    Serial.println("Ask to connect to flow: " + flowId);
    doEvent(RID, Rname, Rcontent);
    nodeRedListenner(RID, Rcontent);
  }
}
