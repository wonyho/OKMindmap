#include "flow.h";
#include "SocketIOClient.h"

SocketIOClient socketIO;
String letters[40] = {"a", "b", "c", "d", "e", "f","g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
String nodeJsAddr = "";
String nodeJsPort = "";
String deviceName = "";
String userName = "";
String pWD = "";
String tkn = "";
String macAddr = "";
//String flowId = "d6862d17.e92d1";
String flowId = "";
extern String RID;
extern String Rname;
extern String Rcontent;

void setFlowId(String id){
  flowId = id;
}

void setMacAddr(String mac){
  macAddr = mac;
}

void setPassword(String pwd){
  pWD = pwd;
}

void setAPIKey(String token){
  tkn = token;
}

void setUserName(String un){
  userName = un;
}

void setDevicesName(String dname){
  deviceName = dname;
}

void setNodeJsAddr(String addr){
  nodeJsAddr = addr;
}

void setNodeJsPort(String port){
  nodeJsPort = port;
}

String randomString(int len){
  String randString = "";
  for(int i = 0; i<len; i++)
  {
   randString = randString + letters[random(0, 40)];
  }
  return randString;
}

void on_flow_connected(String flID){
  flowId = flID;
  write_String(10, flowId);
  Serial.println("Connected to flow has id: " + flowId);
}

void on_flow_connection_error(String error){
  Serial.println("[Error] = " + error);
}

void on_flow_deleted(String result){
  Serial.println("Disconnected flow : ");
}

void on_connected(){
  String payl = randomString(8);
  String nodes = get_flow_template(macAddr, payl, deviceName, nodeJsAddr, nodeJsPort); 
  String json ="{\"mac_addr\" : \""+macAddr+"\", \"flow_id\" : \""+flowId+"\", \"nodes\" : "+nodes+", \"username\" : \""+userName+"\", \"password\" : \""+pWD+"\",\"apikey\" : \""+tkn+"\"}";
  if (socketIO.connected()) {
    socketIO.sendJSON("flow_connection",json);
  }
}

void on_disconnect(const char * payload, size_t length){
  String payl = randomString(8);
  String flow = get_flow_template(macAddr, payl, deviceName, nodeJsAddr, nodeJsPort); 
  
}


void setSocketIO(SocketIOClient sio){
  socketIO = sio;
}

String getResponseValue(String data){
    char separator = ',';
    int found = 0;
    int strIndex[] = {0, -1};
    int maxIndex = data.length() - 1;

    for (int i = 0; i <= maxIndex && found <= 1; i++)
    {
        if (data.charAt(i) == separator || i == maxIndex)
        {
            found++;
            strIndex[0] = strIndex[1] + 1;
            strIndex[1] = (i == maxIndex) ? i + 1 : i;
        }
    }

    return found > 1 ? data.substring(strIndex[0]+1, strIndex[1]-2) : "";
}

void doEvent(String id, String name, String data){
  //Serial.println("event = " + id);
  //Serial.println("data = " + data);
  if(id == "connected"){
    on_connected();
  }else if(id == "flow_connected"){
    on_flow_connected(getResponseValue(data));
  }
}

String getNumberResponseValue(String data){
    char separator = ',';
    int found = 0;
    int strIndex[] = {0, -1};
    int maxIndex = data.length() - 1;

    for (int i = 0; i <= maxIndex && found <= 1; i++)
    {
        if (data.charAt(i) == separator || i == maxIndex)
        {
            found++;
            strIndex[0] = strIndex[1] + 1;
            strIndex[1] = (i == maxIndex) ? i + 1 : i;
        }
    }

    return found > 1 ? data.substring(strIndex[0], strIndex[1]-1) : "";
}

String getStringResponseValue(String data){
    char separator = ',';
    int found = 0;
    int strIndex[] = {0, -1};
    int maxIndex = data.length() - 1;

    for (int i = 0; i <= maxIndex && found <= 1; i++)
    {
        if (data.charAt(i) == separator || i == maxIndex)
        {
            found++;
            strIndex[0] = strIndex[1] + 1;
            strIndex[1] = (i == maxIndex) ? i + 1 : i;
        }
    }

    return found > 1 ? data.substring(strIndex[0]+1, strIndex[1]-2) : "";
}
