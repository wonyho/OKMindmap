#!/usr/bin/env python
import os
from threading import Thread
from socketIO_client_nexus import SocketIO
import gui
import helpers

_dir_ = os.path.dirname(os.path.realpath(__file__))

# ====================================
# Application

def on_init(app):
    # ========================
    def start_camera():
        app.log('Info', 'Start camera service...')
        os.system("python "+_dir_+"/bin/start-camera.py &")
        app.ui_camera_status.set_text('Running')

        cfg = helpers.getConfig()
        cfg['camera_boot'] = '1'
        helpers.setConfig(cfg)

    def stop_camera():
        app.log('Info', 'Stop camera service...')
        os.system(_dir_ + "/bin/stop-camera.sh")
        app.ui_camera_status.set_text('...')

        cfg = helpers.getConfig()
        cfg['camera_boot'] = '0'
        helpers.setConfig(cfg)

    app.ui_start_camera.connect('clicked', lambda s: start_camera())
    app.ui_stop_camera.connect('clicked', lambda s: stop_camera())
    # ========================
    def start_motor_ctrl():
        app.log('Info', 'Start motor control service...')
        os.system("python "+_dir_+"/bin/start-motor-ctrl.py &")
        app.ui_motor_ctrl_status.set_text('Running')

        cfg = helpers.getConfig()
        cfg['motor_ctrl_boot'] = '1'
        helpers.setConfig(cfg)

    def stop_motor_ctrl():
        app.log('Info', 'Stop motor control service...')
        os.system(_dir_+"/bin/stop-motor-ctrl.sh")
        app.ui_motor_ctrl_status.set_text('...')

        cfg = helpers.getConfig()
        cfg['motor_ctrl_boot'] = '0'
        helpers.setConfig(cfg)

    app.ui_start_motor_ctrl.connect('clicked', lambda s: start_motor_ctrl())
    app.ui_stop_motor_ctrl.connect('clicked', lambda s: stop_motor_ctrl())
    # ========================
    # ========================
    def start_dht_sensor():
        app.log('Info', 'Start DHT sensor service...')
        os.system("python "+_dir_+"/bin/start-dht-sensor.py &")
        app.ui_dht_sensor_status.set_text('Running')

        cfg = helpers.getConfig()
        cfg['dht_sensor_boot'] = '1'
        helpers.setConfig(cfg)

    def stop_dht_sensor():
        app.log('Info', 'Stop DHT sensor service...')
        os.system(_dir_ + "/bin/stop-dht-sensor.sh")
        app.ui_dht_sensor_status.set_text('...')

        cfg = helpers.getConfig()
        cfg['dht_sensor_boot'] = '0'
        helpers.setConfig(cfg)

    app.ui_start_dht_sensor.connect('clicked', lambda s: start_dht_sensor())
    app.ui_stop_dht_sensor.connect('clicked', lambda s: stop_dht_sensor())
    # ========================
    
    config = helpers.getConfig()
    
    def on_connected(*arg):
        app.log('Info', 'Connected to server.')
        cfg = helpers.getConfig()
        socketIO.emit('flow_connection', {
            'mac_addr': helpers.getMACAddr(),
            'flow_id': cfg['flow_id'],
            'nodes': helpers.get_flow_template(),
            'username': cfg['username'],
            'password': cfg['password']
        })

    def on_disconnect(*arg):
        stop_services(app)
        app.log('Error', 'Disconnected from the server.')

    def on_flow_connected(*arg):
        app.log('Info', 'Flow ['+arg[0]+'] is ready...')
        _cfg = helpers.getConfig()
        _cfg['flow_id'] = arg[0]
        helpers.setConfig(_cfg)

        start_services(app)

    def on_flow_connection_error(*arg):
        app.log('Error', arg[0])

    def delete_flow():
        app.log('Info', 'Reset flow...')
        cfg = helpers.getConfig()
        socketIO.emit('flow_delete', {
            'flow_id': cfg['flow_id'],
            'username': cfg['username'],
            'password': cfg['password']
        })

    def on_flow_deleted(*arg):
        cfg = helpers.getConfig()
        socketIO.emit('flow_connection', {
            'mac_addr': helpers.getMACAddr(),
            'flow_id': '',
            'nodes': helpers.get_flow_template(),
            'username': cfg['username'],
            'password': cfg['password']
        })

    app.ui_reset.connect('clicked', lambda s: delete_flow())

    socketIO = SocketIO(config['server'], config['port'])

    socketIO.on('flow_connected', on_flow_connected)
    socketIO.on('flow_connection_error', on_flow_connection_error)
    socketIO.on('flow_deleted', on_flow_deleted)

    socketIO.on('connected', on_connected)
    socketIO.on('disconnect', on_disconnect)

    def io_thread():
        socketIO.wait()

    io_th = Thread(target=io_thread)
    io_th.daemon = True
    io_th.start()

def start_services(app):
    cfg = helpers.getConfig()

    if cfg.has_key('camera_boot') and cfg['camera_boot'] == '1':
        app.log('Info', 'Start camera service...')
        os.system("python "+_dir_+"/bin/start-camera.py &")
        app.ui_camera_status.set_text('Running')

    if cfg.has_key('motor_ctrl_boot') and cfg['motor_ctrl_boot'] == '1':
        app.log('Info', 'Start motor control service...')
        os.system("python "+_dir_+"/bin/start-motor-ctrl.py &")
        app.ui_motor_ctrl_status.set_text('Running')

    if cfg.has_key('dht_sensor_boot') and cfg['dht_sensor_boot'] == '1':
        app.log('Info', 'Start DHT sensor service...')
        os.system("python "+_dir_+"/bin/start-dht-sensor.py &")
        app.ui_dht_sensor_status.set_text('Running')

def stop_services(app):
    cfg = helpers.getConfig()

    if cfg.has_key('camera_boot') and cfg['camera_boot'] == '1':
        app.log('Info', 'Stop camera service...')
        os.system(_dir_ + "/bin/stop-camera.sh")
        app.ui_camera_status.set_text('...')

    if cfg.has_key('motor_ctrl_boot') and cfg['motor_ctrl_boot'] == '1':
        app.log('Info', 'Stop motor control service...')
        os.system(_dir_ + "/bin/stop-motor-ctrl.sh")
        app.ui_motor_ctrl_status.set_text('...')

    if cfg.has_key('dht_sensor_boot') and cfg['dht_sensor_boot'] == '1':
        app.log('Info', 'Stop DHT sensor service...')
        os.system(_dir_ + "/bin/stop-dht-sensor.sh")
        app.ui_dht_sensor_status.set_text('...')

def on_reconnect(app):
    app.log(None, None)
    app.log('Info', '...refresh...')
    stop_services(app)
    on_init(app)


if __name__ == "__main__":
    try:
        gui.AppWindow(on_init, on_reconnect, stop_services)
    except KeyboardInterrupt:
        print('destroy!')
