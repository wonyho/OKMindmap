sudo pip install socketIO-client-nexus PyGObject picamera Adafruit-DHT RPi.GPIO

