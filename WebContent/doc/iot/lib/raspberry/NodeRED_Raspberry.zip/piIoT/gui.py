#!/usr/bin/env python
import os
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
from threading import Thread
import urllib2
import time

import helpers

# ====================================
# GUI

_dir_ = os.path.dirname(os.path.realpath(__file__))
UI_XML = _dir_+'/ui.glade'

class AppWindow:
    def __init__(self, *args):
        # *args: on_init, on_reconnect, on_destroy
        if len(args) >= 1 and args[0] is not None : self.on_init = args[0]
        else : self.on_init = lambda s: None

        if len(args) >= 2 and args[1] is not None : self.on_reconnect = args[1]
        else : self.on_reconnect = lambda s: None

        if len(args) >= 3 and args[2] is not None : self.on_destroy = args[2]
        else : self.on_destroy = lambda s: None
        
        
        builder = Gtk.Builder()
        builder.add_from_file(UI_XML)

        self.ui_window = builder.get_object('wMain')

        self.ui_config = builder.get_object('btnConfig')
        self.ui_reconnect = builder.get_object('btnReconnect')
        self.ui_clear_logs = builder.get_object('btnClearLogs')

        self.ui_reset = builder.get_object('btnReset')
        
        self.ui_logs = builder.get_object('txtLogs')

        self.ui_camera_status = builder.get_object('lblCameraStatus')
        self.ui_start_camera = builder.get_object('btnStartCamera')
        self.ui_stop_camera = builder.get_object('btnStopCamera')

        self.ui_motor_ctrl_status = builder.get_object('lblMotorCtrlStatus')
        self.ui_start_motor_ctrl = builder.get_object('btnStartMotorCtrl')
        self.ui_stop_motor_ctrl = builder.get_object('btnStopMotorCtrl')

        self.ui_dht_sensor_status = builder.get_object('lblDHTSensorStatus')
        self.ui_start_dht_sensor = builder.get_object('btnStartDHTSensor')
        self.ui_stop_dht_sensor = builder.get_object('btnStopDHTSensor')

        self.ui_window.connect('destroy', self.onAppDestroy)

        def _thread():
            self.log('Info', 'Waiting for network connection...')
            while True:
                try:
                    urllib2.urlopen('http://www.google.com').close()
                except urllib2.URLError:
                    time.sleep(1)
                else:
                    self.ui_config.connect('clicked', lambda s: ConfigWindow())
                    self.ui_reconnect.connect('clicked', lambda s: self.on_reconnect(self))
                    self.ui_clear_logs.connect('clicked', lambda s: self.log(None, None))
                    self.on_init(self)
                    break

        _th = Thread(target=_thread)
        _th.daemon = True

        _cfg = helpers.getConfig()
        if _cfg.has_key('init') and _cfg['init'] == '1':
            _th.start()
        else :
            InstallWindow(lambda : _th.start())

        self.ui_window.show_all()
        Gtk.main()

    def log(self, info, msg):
        buf = self.ui_logs.get_buffer()
        if msg is None:
            buf.set_text('')
        else :
            end_iter = buf.get_end_iter()
            buf.insert(end_iter, '['+info+']  ' + msg + '\n')
        self.ui_logs.set_buffer(buf)
        self.ui_logs.show()

    def onAppDestroy(self, *args):
        self.on_destroy(self)
        Gtk.main_quit()

class ConfigWindow:
    def __init__(self, *args):
        # *args: on_save
        if len(args) >= 1 and args[0] is not None : self.on_save = args[0]
        else : self.on_save = lambda : None
        
        builder = Gtk.Builder()
        builder.add_from_file(UI_XML)
        self.window = builder.get_object('wConfig')

        self.ui_mac_addr = builder.get_object('lblMacAddr')
        self.ui_device_name = builder.get_object('txtDeviceName')
        self.ui_flow_id = builder.get_object('txtFlowId')
        self.ui_run_at_startup = builder.get_object('chkRunAtStartup')
        
        self.ui_server = builder.get_object('txtServer')
        self.ui_port = builder.get_object('txtPort')
        self.ui_username = builder.get_object('txtUsername')
        self.ui_password = builder.get_object('txtPassword')

        self.ui_save = builder.get_object('btnSave')
        self.ui_save.connect('clicked', self.doSave)

        self.ui_cancel = builder.get_object('btnCancel')
        self.ui_cancel.connect('clicked', lambda s: self.window.destroy())

        self.loadFormData()
        self.window.show_all()

    def loadFormData(self):
        config = helpers.getConfig()
        mac_addr = helpers.getMACAddr()

        self.ui_mac_addr.set_text(mac_addr)
        if config.has_key('device_name'): self.ui_device_name.set_text(config['device_name'])
        if config.has_key('flow_id'): self.ui_flow_id.set_text(config['flow_id'])
        if config.has_key('run_at_startup'): self.ui_run_at_startup.set_active(config['run_at_startup'] == '1')

        if config.has_key('server'): self.ui_server.set_text(config['server'])
        if config.has_key('port'): self.ui_port.set_text(config['port'])
        if config.has_key('username'): self.ui_username.set_text(config['username'])
        if config.has_key('password'): self.ui_password.set_text(config['password'])
            
    def doSave(self, w):
        config = helpers.getConfig()
        
        config['device_name'] = self.ui_device_name.get_text()
        config['flow_id'] = self.ui_flow_id.get_text()
        if self.ui_run_at_startup.get_active() is True:
            config['run_at_startup'] = '1'
            helpers.registerService()
        else :
            config['run_at_startup'] = '0'
            helpers.unregisterService()
        
        config['server'] = self.ui_server.get_text()
        config['port'] = self.ui_port.get_text()
        config['username'] = self.ui_username.get_text()
        config['password'] = self.ui_password.get_text()

        helpers.setConfig(config)
        
        self.on_save()
        self.window.destroy()

class InstallWindow:
    def __init__(self, *args):
        # *args: on_save
        if len(args) >= 1 and args[0] is not None : self.on_save = args[0]
        else : self.on_save = lambda : None
        
        builder = Gtk.Builder()
        builder.add_from_file(UI_XML)
        self.window = builder.get_object('wInstall')

        self.ui_init_device_name = builder.get_object('txtInitDeviceName')
        self.ui_init_run_at_startup = builder.get_object('chkInitRunAtStartup')
        
        self.ui_save = builder.get_object('btnInitSave')
        self.ui_save.connect('clicked', self.doSave)

        self.window.show_all()

    def doSave(self, w):
        config = helpers.getConfig()
        
        config['init'] = '1'
        config['device_name'] = self.ui_init_device_name.get_text()
        if config['device_name'] == '':
            config['device_name'] = 'Raspberry PI ' + helpers.getMACAddr()

        if self.ui_init_run_at_startup.get_active() is True:
            config['run_at_startup'] = '1'
            helpers.registerService()
        else :
            config['run_at_startup'] = '0'
            helpers.unregisterService()

        config['flow_id'] = ''
        
        helpers.setConfig(config)
        
        self.on_save()
        self.window.destroy()
