#!/usr/bin/env python
import os
import json
import random, string

_dir_ = os.path.dirname(os.path.realpath(__file__))
CONFIG_FILE = _dir_ + '/config.json'
AUTOSTART_FILE = '/home/pi/.config/lxsession/LXDE-pi/autostart'

# ====================================
# Helper functions

def getMACAddr(interface='eth0'):
    try:
        str = open('/sys/class/net/%s/address' %interface).read()
    except:
        str = "00:00:00:00:00:00"
    return str[0:17]

def getConfig():
    with open(CONFIG_FILE) as json_file:  
        config = json.load(json_file)
    return config

def setConfig(config):
    with open(CONFIG_FILE, 'w') as outfile:
        json.dump(config, outfile)

def get_flow_template():
    cfg = getConfig()
    mac_addr = getMACAddr()
    with open(_dir_+'/flow.json', 'r') as f:  
        flow = f.read()
    flow = flow.replace('@@MAC_ADDR@@', mac_addr)
    flow = flow.replace('@@PAYLOAD@@', randomword(8))
    flow = flow.replace('@@DEVICE_NAME@@', cfg['device_name'])
    flow = flow.replace('@@SERVER@@', cfg['server'])
    
    cam_url = 'cam-' + mac_addr.replace(':', '-')
    flow = flow.replace('@@CAM_URL@@', cam_url)
    return json.loads(flow)

def unregisterService():
    with open(AUTOSTART_FILE, 'r') as f:  
        config = f.read()
    config = config.replace('@lxterminal -e '+_dir_+'/app.py', '')
    with open(AUTOSTART_FILE, 'w') as outfile:
        outfile.write(config)

def registerService():
    with open(AUTOSTART_FILE, 'r') as f:  
        config = f.read()
    config = config.replace('@lxterminal -e '+_dir_+'/app.py', '')
    config = config + '@lxterminal -e '+_dir_+'/app.py'
    with open(AUTOSTART_FILE, 'w') as outfile:
        outfile.write(config)

def randomword(length):
   letters = string.ascii_lowercase
   return ''.join(random.choice(letters) for i in range(length))

